"use strict";
/**
 * ============================================================================
 * WALLET ENDPOINTS - LAMBDA VERSION WITH ROW-LEVEL LOCKING
 * ============================================================================
 *
 * Provides atomic wallet operations with concurrency safety
 *
 * Endpoints:
 * - GET /wallet/:customerId - Get wallet balance
 * - POST /wallet/:customerId/credit - Credit wallet (add funds)
 * - POST /wallet/:customerId/debit - Debit wallet (spend funds)
 * - GET /wallet/:customerId/transactions - Get transaction history
 *
 * Date: 2026-01-03
 * ============================================================================
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerWalletEndpoints = registerWalletEndpoints;
const base_handler_1 = require("../handler/base-handler");
const rds_connection_1 = require("../database/rds-connection");
const audit_log_1 = require("../utils/audit-log");
const idempotency_1 = require("../utils/idempotency");
// ============================================================================
// WALLET HANDLERS
// ============================================================================
class GetWalletHandler extends base_handler_1.BaseHandler {
    async handle(context) {
        const customerId = context.event.pathParameters?.customerId;
        if (!customerId) {
            return this.error('Customer ID is required', 400);
        }
        // Get or create wallet
        const wallet = await this.getOrCreateWallet(customerId);
        return this.success({
            customerId: wallet.customer_id,
            balance: parseFloat(wallet.balance),
            currency: wallet.currency || 'INR',
            lastUpdated: wallet.updated_at,
        });
    }
    async getOrCreateWallet(customerId) {
        let wallets = await (0, rds_connection_1.select)('customer_wallets', { customer_id: customerId });
        if (wallets.length === 0) {
            // Create new wallet
            const result = await (0, rds_connection_1.query)(`INSERT INTO customer_wallets (customer_id, balance, currency)
         VALUES ($1, 0, 'INR')
         ON CONFLICT (customer_id) DO NOTHING
         RETURNING *`, [customerId]);
            if (result.rows.length > 0) {
                return result.rows[0];
            }
            // If insert failed due to race condition, try select again
            wallets = await (0, rds_connection_1.select)('customer_wallets', { customer_id: customerId });
        }
        return wallets[0];
    }
}
class CreditWalletHandler extends base_handler_1.BaseHandler {
    async handle(context) {
        const customerId = context.event.pathParameters?.customerId;
        const body = this.parseBody(context.event);
        const { amount, referenceType, referenceId, description, idempotencyKey } = body;
        const requestId = context.event.requestContext?.requestId;
        if (!customerId) {
            return this.error('Customer ID is required', 400);
        }
        this.validateRequired(body, ['amount']);
        // Validate amount
        if (typeof amount !== 'number' || amount <= 0) {
            return this.error('Amount must be a positive number', 400);
        }
        // ✅ TEMPORAL FIX: Check idempotency
        if (idempotencyKey) {
            const existing = await (0, idempotency_1.checkIdempotencyKey)(idempotencyKey);
            if (existing.exists) {
                return this.success({
                    ...existing.response,
                    cached: true,
                    message: 'Transaction already processed',
                });
            }
        }
        // ✅ TEMPORAL FIX: Use transaction with row-level locking
        const result = await (0, rds_connection_1.withTransaction)(async (client) => {
            // Lock wallet row FOR UPDATE (prevents concurrent modifications)
            const walletResult = await client.query(`SELECT id, customer_id, balance, currency
         FROM customer_wallets
         WHERE customer_id = $1
         FOR UPDATE`, [customerId]);
            let wallet;
            if (walletResult.rows.length === 0) {
                // Create wallet if doesn't exist
                const createResult = await client.query(`INSERT INTO customer_wallets (customer_id, balance, currency)
           VALUES ($1, $2, 'INR')
           RETURNING *`, [customerId, amount]);
                wallet = createResult.rows[0];
            }
            else {
                wallet = walletResult.rows[0];
                // Update balance atomically
                const updateResult = await client.query(`UPDATE customer_wallets
           SET balance = balance + $1, updated_at = NOW()
           WHERE customer_id = $2
           RETURNING *`, [amount, customerId]);
                wallet = updateResult.rows[0];
            }
            // Record transaction
            const txnResult = await client.query(`INSERT INTO wallet_transactions (
          customer_id, transaction_type, amount, balance_after,
          reference_type, reference_id, description
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *`, [
                customerId,
                'credit',
                amount,
                wallet.balance,
                referenceType || null,
                referenceId || null,
                description || null,
            ]);
            return {
                wallet,
                transaction: txnResult.rows[0],
            };
        });
        // ✅ TEMPORAL FIX: Log audit entry
        await (0, audit_log_1.logAuditEntry)({
            entityType: 'wallet',
            entityId: result.wallet.id,
            action: 'credit',
            newValues: {
                amount,
                balanceAfter: result.wallet.balance,
                referenceType,
                referenceId,
            },
            actorId: customerId,
            actorType: 'customer',
            requestId,
        });
        const response = {
            transactionId: result.transaction.id,
            customerId,
            amount: Number(amount),
            newBalance: Number(result.wallet.balance),
            transactionType: 'credit',
            timestamp: result.transaction.created_at,
            message: 'Wallet credited successfully',
        };
        // ✅ TEMPORAL FIX: Store idempotency key
        if (idempotencyKey) {
            await (0, idempotency_1.storeIdempotencyKey)(idempotencyKey, 'wallet_transaction', result.transaction.id, response, 200);
        }
        return this.success(response);
    }
}
class DebitWalletHandler extends base_handler_1.BaseHandler {
    async handle(context) {
        const customerId = context.event.pathParameters?.customerId;
        const body = this.parseBody(context.event);
        const { amount, referenceType, referenceId, description, idempotencyKey } = body;
        const requestId = context.event.requestContext?.requestId;
        if (!customerId) {
            return this.error('Customer ID is required', 400);
        }
        this.validateRequired(body, ['amount']);
        // Validate amount
        if (typeof amount !== 'number' || amount <= 0) {
            return this.error('Amount must be a positive number', 400);
        }
        // ✅ TEMPORAL FIX: Check idempotency
        if (idempotencyKey) {
            const existing = await (0, idempotency_1.checkIdempotencyKey)(idempotencyKey);
            if (existing.exists) {
                return this.success({
                    ...existing.response,
                    cached: true,
                    message: 'Transaction already processed',
                });
            }
        }
        // ✅ TEMPORAL FIX: Use transaction with row-level locking
        try {
            const result = await (0, rds_connection_1.withTransaction)(async (client) => {
                // Lock wallet row FOR UPDATE
                const walletResult = await client.query(`SELECT id, customer_id, balance, currency
           FROM customer_wallets
           WHERE customer_id = $1
           FOR UPDATE`, [customerId]);
                if (walletResult.rows.length === 0) {
                    throw new Error('Wallet not found');
                }
                const wallet = walletResult.rows[0];
                // Check sufficient balance
                if (parseFloat(wallet.balance) < amount) {
                    throw new Error('Insufficient balance');
                }
                // Update balance atomically
                const updateResult = await client.query(`UPDATE customer_wallets
           SET balance = balance - $1, updated_at = NOW()
           WHERE customer_id = $2 AND balance >= $1
           RETURNING *`, [amount, customerId]);
                if (updateResult.rows.length === 0) {
                    throw new Error('Insufficient balance (race condition)');
                }
                const updatedWallet = updateResult.rows[0];
                // Record transaction
                const txnResult = await client.query(`INSERT INTO wallet_transactions (
            customer_id, transaction_type, amount, balance_after,
            reference_type, reference_id, description
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)
          RETURNING *`, [
                    customerId,
                    'debit',
                    amount,
                    updatedWallet.balance,
                    referenceType || null,
                    referenceId || null,
                    description || null,
                ]);
                return {
                    wallet: updatedWallet,
                    transaction: txnResult.rows[0],
                };
            });
            // ✅ TEMPORAL FIX: Log audit entry
            await (0, audit_log_1.logAuditEntry)({
                entityType: 'wallet',
                entityId: result.wallet.id,
                action: 'debit',
                newValues: {
                    amount,
                    balanceAfter: result.wallet.balance,
                    referenceType,
                    referenceId,
                },
                actorId: customerId,
                actorType: 'customer',
                requestId,
            });
            const response = {
                transactionId: result.transaction.id,
                customerId,
                amount: Number(amount),
                newBalance: Number(result.wallet.balance),
                transactionType: 'debit',
                timestamp: result.transaction.created_at,
                message: 'Wallet debited successfully',
            };
            // ✅ TEMPORAL FIX: Store idempotency key
            if (idempotencyKey) {
                await (0, idempotency_1.storeIdempotencyKey)(idempotencyKey, 'wallet_transaction', result.transaction.id, response, 200);
            }
            return this.success(response);
        }
        catch (error) {
            if (error.message.includes('Insufficient balance')) {
                return this.error('Insufficient wallet balance', 400);
            }
            if (error.message.includes('Wallet not found')) {
                return this.error('Wallet not found', 404);
            }
            throw error;
        }
    }
}
class GetWalletTransactionsHandler extends base_handler_1.BaseHandler {
    async handle(context) {
        const customerId = context.event.pathParameters?.customerId;
        const limit = parseInt(context.event.queryStringParameters?.limit || '50');
        const offset = parseInt(context.event.queryStringParameters?.offset || '0');
        if (!customerId) {
            return this.error('Customer ID is required', 400);
        }
        const result = await (0, rds_connection_1.query)(`SELECT * FROM wallet_transactions
       WHERE customer_id = $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`, [customerId, Math.min(limit, 100), offset]);
        const transactions = result.rows.map((row) => ({
            id: row.id,
            type: row.transaction_type,
            amount: parseFloat(row.amount),
            balanceAfter: parseFloat(row.balance_after),
            referenceType: row.reference_type,
            referenceId: row.reference_id,
            description: row.description,
            timestamp: row.created_at,
        }));
        return this.success({
            transactions,
            count: transactions.length,
            limit,
            offset,
        });
    }
}
// ============================================================================
// HONO ROUTER SETUP
// ============================================================================
function registerWalletEndpoints(app) {
    const getWalletHandler = new GetWalletHandler();
    const creditWalletHandler = new CreditWalletHandler();
    const debitWalletHandler = new DebitWalletHandler();
    const getTransactionsHandler = new GetWalletTransactionsHandler();
    app.get('/wallet/:customerId', async (c) => {
        const event = createApiGatewayEvent(c.req);
        event.pathParameters = { customerId: c.req.param('customerId') };
        const context = createLambdaContext();
        const result = await getWalletHandler.execute(event, context);
        return c.json(JSON.parse(result.body), result.statusCode);
    });
    app.post('/wallet/:customerId/credit', async (c) => {
        const event = createApiGatewayEvent(c.req);
        event.pathParameters = { customerId: c.req.param('customerId') };
        const context = createLambdaContext();
        const result = await creditWalletHandler.execute(event, context);
        return c.json(JSON.parse(result.body), result.statusCode);
    });
    app.post('/wallet/:customerId/debit', async (c) => {
        const event = createApiGatewayEvent(c.req);
        event.pathParameters = { customerId: c.req.param('customerId') };
        const context = createLambdaContext();
        const result = await debitWalletHandler.execute(event, context);
        return c.json(JSON.parse(result.body), result.statusCode);
    });
    app.get('/wallet/:customerId/transactions', async (c) => {
        const event = createApiGatewayEvent(c.req);
        event.pathParameters = { customerId: c.req.param('customerId') };
        const context = createLambdaContext();
        const result = await getTransactionsHandler.execute(event, context);
        return c.json(JSON.parse(result.body), result.statusCode);
    });
}
function createApiGatewayEvent(req) {
    return {
        httpMethod: req.method,
        path: req.url,
        headers: Object.fromEntries(req.headers || []),
        body: JSON.stringify(req.body || {}),
        pathParameters: {},
        queryStringParameters: Object.fromEntries(new URL(req.url, 'http://localhost').searchParams),
        requestContext: {
            requestId: crypto.randomUUID(),
        },
    };
}
function createLambdaContext() {
    return {
        requestId: crypto.randomUUID(),
        functionName: 'wallet-handler',
        functionVersion: '$LATEST',
    };
}
//# sourceMappingURL=wallet.js.map