"use strict";
/**
 * ============================================================================
 * SEARCH ENDPOINTS - LAMBDA VERSION WITH OPENSEARCH FALLBACK
 * ============================================================================
 *
 * Handles search for services and vendors with intelligent fallback:
 * 1. Try OpenSearch (if available)
 * 2. Fall back to PostgreSQL full-text search
 *
 * - Universal service discovery
 * - Vendor search
 * - Service search
 * - Problem-based discovery
 *
 * Date: 2025-01-28 (Updated: 2026-01-02)
 * Migration: Supabase to AWS Lambda
 * ============================================================================
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerSearchEndpoints = registerSearchEndpoints;
const base_handler_1 = require("../handler/base-handler");
const rds_connection_1 = require("../database/rds-connection");
// Import OpenSearch client with fallback handling
let openSearchClient = null;
try {
    const { getOpenSearchClient } = require('../utils/opensearch-client');
    openSearchClient = getOpenSearchClient();
}
catch (error) {
    console.warn('⚠️  OpenSearch client not available, will use SQL fallback');
}
// ============================================================================
// SEARCH HANDLERS
// ============================================================================
class UniversalSearchHandler extends base_handler_1.BaseHandler {
    async handle(context) {
        const searchQuery = context.event.queryStringParameters?.q || '';
        const category = context.event.queryStringParameters?.category;
        const location = context.event.queryStringParameters?.location;
        const limit = parseInt(context.event.queryStringParameters?.limit || '20', 10);
        if (!searchQuery && !category) {
            return this.error('Search query or category is required', 400);
        }
        // Try OpenSearch first if available
        if (openSearchClient && process.env.ENABLE_OPENSEARCH === 'true') {
            try {
                console.log('🔍 Using OpenSearch for search query:', searchQuery);
                return await this.searchWithOpenSearch(searchQuery, category, location, limit);
            }
            catch (error) {
                console.warn('⚠️  OpenSearch failed, falling back to SQL:', error);
                // Fall through to SQL search
            }
        }
        else {
            console.log('🔍 Using SQL fallback for search query:', searchQuery);
        }
        // ✅ SQL Fallback: Search vendors and services using PostgreSQL
        return await this.searchWithSQL(searchQuery, category, location, limit);
    }
    /**
     * Search using OpenSearch (primary method)
     */
    async searchWithOpenSearch(searchQuery, category, location, limit) {
        const searchBody = {
            query: {
                bool: {
                    must: [],
                    filter: [],
                },
            },
            size: limit,
        };
        // Add search query
        if (searchQuery) {
            searchBody.query.bool.must.push({
                multi_match: {
                    query: searchQuery,
                    fields: ['business_name^3', 'service_name^2', 'description', 'specialization'],
                    fuzziness: 'AUTO',
                },
            });
        }
        // Add category filter
        if (category) {
            searchBody.query.bool.filter.push({ term: { category } });
        }
        // Add location filter
        if (location) {
            searchBody.query.bool.filter.push({ term: { city: location.toLowerCase() } });
        }
        // Add status filters
        searchBody.query.bool.filter.push({ term: { is_active: true } });
        searchBody.query.bool.filter.push({ term: { status: 'approved' } });
        const result = await openSearchClient.search({
            index: 'warmpawz-vendors,warmpawz-services',
            body: searchBody,
        });
        const hits = result.body.hits.hits;
        const vendors = [];
        const services = [];
        hits.forEach((hit) => {
            const source = hit._source;
            if (hit._index.includes('vendors')) {
                vendors.push({
                    id: source.id,
                    businessName: source.business_name,
                    ownerName: source.owner_name,
                    category: source.category,
                    city: source.city,
                    state: source.state,
                    rating: source.rating || 0,
                    completedBookings: source.completed_bookings || 0,
                });
            }
            else {
                services.push({
                    id: source.id,
                    serviceName: source.service_name,
                    description: source.description,
                    price: source.price,
                    vendorId: source.vendor_id,
                    vendorName: source.vendor_name,
                    city: source.city,
                    state: source.state,
                });
            }
        });
        return this.success({
            query: searchQuery,
            vendors,
            services,
            total: hits.length,
            searchMethod: 'opensearch',
        });
    }
    /**
     * Search using SQL (fallback method)
     */
    async searchWithSQL(searchQuery, category, location, limit) {
        // ✅ SQL: Search vendors and services
        let vendorsQuery = `
      SELECT v.*, 
             (SELECT COUNT(*) FROM bookings b WHERE b.vendor_id = v.id AND b.status = 'completed') as completed_bookings,
             (SELECT AVG(rating) FROM reviews r WHERE r.vendor_id = v.id) as avg_rating
      FROM vendors v
      WHERE v.is_active = true 
        AND v.status = 'approved'
    `;
        const params = [];
        let paramIndex = 1;
        if (searchQuery) {
            vendorsQuery += ` AND (
        v.business_name ILIKE $${paramIndex} OR
        v.owner_name ILIKE $${paramIndex} OR
        v.specialization ILIKE $${paramIndex}
      )`;
            params.push(`%${searchQuery}%`);
            paramIndex++;
        }
        if (category) {
            vendorsQuery += ` AND v.category = $${paramIndex}`;
            params.push(category);
            paramIndex++;
        }
        if (location) {
            // Simple location filtering - in production, use geospatial queries
            vendorsQuery += ` AND v.city ILIKE $${paramIndex}`;
            params.push(`%${location}%`);
            paramIndex++;
        }
        vendorsQuery += ` ORDER BY avg_rating DESC NULLS LAST, completed_bookings DESC LIMIT $${paramIndex}`;
        params.push(limit);
        const { rows: vendors } = await (0, rds_connection_1.query)(vendorsQuery, params);
        // ✅ SQL: Search services
        let servicesQuery = `
      SELECT vs.*, v.business_name, v.owner_name, v.city, v.state
      FROM vendor_services vs
      JOIN vendors v ON vs.vendor_id = v.id
      WHERE vs.publish_status = 'published'
        AND vs.is_enabled = true
        AND v.is_active = true
        AND v.status = 'approved'
    `;
        const serviceParams = [];
        let serviceParamIndex = 1;
        if (searchQuery) {
            servicesQuery += ` AND (
        vs.service_name ILIKE $${serviceParamIndex} OR
        vs.description ILIKE $${serviceParamIndex}
      )`;
            serviceParams.push(`%${searchQuery}%`);
            serviceParamIndex++;
        }
        if (category) {
            servicesQuery += ` AND vs.category = $${serviceParamIndex}`;
            serviceParams.push(category);
            serviceParamIndex++;
        }
        servicesQuery += ` LIMIT $${serviceParamIndex}`;
        serviceParams.push(limit);
        const { rows: services } = await (0, rds_connection_1.query)(servicesQuery, serviceParams);
        return this.success({
            query: searchQuery,
            vendors: vendors.map(v => ({
                id: v.id,
                businessName: v.business_name,
                ownerName: v.owner_name,
                category: v.category,
                city: v.city,
                state: v.state,
                rating: parseFloat(v.avg_rating) || 0,
                completedBookings: parseInt(v.completed_bookings) || 0,
            })),
            services: services.map(s => ({
                id: s.id,
                serviceName: s.service_name,
                description: s.description,
                price: s.price,
                vendorId: s.vendor_id,
                vendorName: s.business_name,
                city: s.city,
                state: s.state,
            })),
            total: vendors.length + services.length,
            searchMethod: 'sql-fallback',
        });
    }
}
// ============================================================================
// HONO ROUTER SETUP
// ============================================================================
function registerSearchEndpoints(app) {
    const searchHandler = new UniversalSearchHandler();
    app.get('/search', async (c) => {
        const event = createApiGatewayEvent(c.req);
        const context = createLambdaContext();
        const result = await searchHandler.execute(event, context);
        return c.json(JSON.parse(result.body), result.statusCode);
    });
}
function createApiGatewayEvent(req) {
    return {
        httpMethod: req.method,
        path: req.url,
        headers: req.headers,
        body: JSON.stringify(req.body || {}),
        pathParameters: req.param() || {},
        queryStringParameters: Object.fromEntries(new URL(req.url).searchParams),
        requestContext: {
            requestId: crypto.randomUUID(),
        },
    };
}
function createLambdaContext() {
    return {
        requestId: crypto.randomUUID(),
        functionName: 'search-handler',
        functionVersion: '$LATEST',
    };
}
//# sourceMappingURL=search.js.map