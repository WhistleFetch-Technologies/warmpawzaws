declare module 'firebase-admin';

